#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cerrno>
#include <vector>
#include <cctype>
#include <string>
#include <time.h>
#include <sys/time.h>
#include <ctime>
#include <locale.h>
using namespace std;

struct Cliente
{
    int id;
    char nombre[45];
    char direccion[70];
    char telefono[18];
};

struct Producto
{
    int id;
    int id_proveedor;
    int stock;
    float precio;
    char description[45];
    int stock_min;
};

int inicializarArchivos();

void listarClientes(const char file[21]), listarProductos(), busquedaBinaria(), listarProductosAlfabeticos();

void ordenamientoMezclaDirecta();
void distribuir(const char* f, const char* f1, const char* f2, int longSec, int numReg);
void subSecuencia(ifstream &f, ofstream &t, int longSec);
void mezclar(const char* f1, const char* f2, const char* f, int lonSec, int numReg);

void ordenamientoMezclaNatural();
void distribuirNatural(const char* f, const char* f1, const char* f2, int longSec, int numReg);
void subSecuenciaNatural(std::ifstream &f, std::ofstream &t, int longSec);


int main()
{
	setlocale(LC_ALL, "");
    int opcion;
    do
    {
        do
        {
            system("cls");
            cout << "*************** MEN� PRINCIPAL ***************\n\n";
            cout << "1. Lista de cliente\n";
            cout << "2. Lista de productos\n";
            cout << "3. Ordenamiento de productos por Quicksort\n";
            cout << "4. Ordenamiento de clientes por mezcla directa\n";
            cout << "5. Ordenamiento de clientes por mezcla natural\n";
            cout << "6. B�squeda binaria de productos\n";
            cout << "7. Salir\n";
            cout << "Ingrese su opci�n: ";
            fflush(stdin);
            cin >> opcion;

            if (opcion < 0 || opcion > 7)
            {
                system("cls");
                cout << "Ingrese una opci�n v�lida\n\n";
                system("pause");
            }
        } while (opcion < 0 || opcion > 7);

        if (opcion == 1)
        {
            listarClientes("Cliente.bin");
            system("pause");
        }
        else if (opcion == 2)
        {
            listarProductos();
        }
        else if (opcion == 3)
        {
            listarProductosAlfabeticos();
        }
        else if (opcion == 4)
        {
            ordenamientoMezclaDirecta();
        }
        else if (opcion == 5) 
		{
        	ordenamientoMezclaNatural();
		}
        else if (opcion == 6)
        {
            busquedaBinaria();
        }
        else if (opcion == 7)
        {
        	cout << "\n\n �Hasta luego!";
		}

    } while (opcion != 7);
}

void listarClientes(const char *file)
{
    Cliente cliente;
    ifstream archivo;
    archivo.open(file, ios::in | ios::binary);

    if (archivo.fail())
    {
        cout << "No se pudo abrir el archivo: " << strerror(errno);
        EXIT_FAILURE;
    }

    system("cls");
    cout << "************************************** LISTA DE CLIENTES **************************************" << endl;
    cout << setw(13) << left << "ID";
    cout << setw(30) << left << "NOMBRE";
    cout << setw(40) << left << "DIRECCI�N";
    cout << "TEL�FONO\n"
         << endl;

    while (archivo.read((char *)&cliente, sizeof(Cliente)))
    {
        cout << setw(13) << left << cliente.id;
        cout << setw(30) << left << cliente.nombre;
        cout << setw(40) << left << cliente.direccion;
        cout << cliente.telefono << endl;
    }

    cout << endl;
    archivo.close();
}

void listarProductos()
{
    Producto producto;
    ifstream archivo;
    archivo.open("Producto.bin", ios::in | ios::binary);

    if (archivo.fail())
    {
        cout << "No se pudo abrir el archivo: " << strerror(errno);
        EXIT_FAILURE;
    }

    system("cls");
    cout << "*********************************************** LISTA DE PRODUCTOS ***********************************************" << endl;
    cout << setw(10) << left << "ID";
    cout << setw(55) << left << "DESCRIPCI�N";
    cout << setw(15) << left << "ID PROVEEDOR";
    cout << setw(10) << left << "CANTIDAD";
    cout << setw(15) << left << "STOCK M�NIMO";
    cout << "PRECIO ($)\n"
         << endl;

    while (archivo.read((char *)&producto, sizeof(Producto)))
    {
        cout << setw(10) << left << producto.id;
        cout << setw(55) << left << producto.description;
        cout << setw(15) << left << producto.id_proveedor;
        cout << setw(10) << left << producto.stock;
        cout << setw(15) << left << producto.stock_min;
        cout << fixed << setprecision(2) << producto.precio << endl;
    }

    cout << endl;
    archivo.close();
    system("pause");
}

int partition(vector<Producto> &productos, int low, int high)
{
    string pivot = productos[high].description;
    int i = (low - 1);
    for (int j = low; j <= high - 1; j++)
    {
        if (productos[j].description < pivot)
        {
            i++;
            swap(productos[i], productos[j]);
        }
    }
    swap(productos[i + 1], productos[high]);
    return (i + 1);
}

void quickSort(vector<Producto> &productos, int low, int high)
{
    if (low < high)
    {
        int pi = partition(productos, low, high);
        quickSort(productos, low, pi - 1);
        quickSort(productos, pi + 1, high);
    }
}

void listarProductosAlfabeticos()
{
    char busqueda[45];
    vector<Producto> productos;
    Producto temporal;
    ifstream archivo;
    struct timeval t, t2;
    int microsegundos;
    gettimeofday(&t, NULL);

    archivo.open("Producto.bin", ios::in | ios::binary);

    if (archivo.fail())
    {
        system("cls");
        cout << "No se pudo abrir el archivo: " << strerror(errno);
        EXIT_FAILURE;
    }

    while (archivo.read((char *)&temporal, sizeof(Producto)))
    {
        productos.push_back(temporal);
    }

    for (int i = 0; i < productos.size(); i++)
    {
        for (int j = 0; j < strlen(productos[i].description); j++)
        {
            productos[i].description[j] = toupper(productos[i].description[j]);
        }
    }

    quickSort(productos, 0, productos.size() - 1);

    gettimeofday(&t2, NULL);
    microsegundos = ((t2.tv_usec - t.tv_usec) + ((t2.tv_sec - t.tv_sec) * 1000000.0f));

    system("cls");

    cout << setw(10) << left << "ID";
    cout << setw(55) << left << "DESCRIPCION";
    cout << setw(15) << left << "ID PROVEEDOR";
    cout << setw(10) << left << "CANTIDAD";
    cout << setw(15) << left << "STOCK MINIMO";
    cout << "PRECIO ($)\n"
         << endl;

    for (int i = 0; i < productos.size(); i++)
    {
        cout << setw(10) << left << productos[i].id;
        cout << setw(55) << left << productos[i].description;
        cout << setw(15) << left << productos[i].id_proveedor;
        cout << setw(10) << left << productos[i].stock;
        cout << setw(15) << left << productos[i].stock_min;
        cout << fixed << setprecision(2) << productos[i].precio << endl;
    }
    printf("\nOrdenamiento por Quicksort terminado en: %g microsegundos.\n\n", microsegundos);
    system("pause");
}

void busquedaBinaria()
{

    char busqueda[45];
    vector<Producto> productos;
    Producto temporal;
    ifstream archivo;

    archivo.open("Producto.bin", ios::in | ios::binary);

    if (archivo.fail())
    {
        system("cls");
        cout << "No se pudo abrir el archivo: " << strerror(errno);
        EXIT_FAILURE;
    }

    while (archivo.read((char *)&temporal, sizeof(Producto)))
    {
        productos.push_back(temporal);
    }

    for (int i = 0; i < productos.size(); i++)
    {
        for (int j = 0; j < strlen(productos[i].description); j++)
        {
            productos[i].description[j] = toupper(productos[i].description[j]);
        }
    }

    quickSort(productos, 0, productos.size() - 1);

    system("cls");
    cout << "******** B�SQUEDA DE PRODUCTOS ********"<<endl << endl;
    cout << "Introduzca la descripci�n del producto: ";
    fflush(stdin);
    cin.getline(busqueda, 45);

    int low = 0;
    int high = productos.size() - 1;
    int mid;
    bool encontrado = false;

    while (low <= high)
    {
        mid = (low + high) / 2;
        int comparasion = strcasecmp(productos[mid].description, busqueda);

        if (comparasion == 0)
        {
            encontrado = true;
            break;
        }
        else if (comparasion < 0)
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }

    if (encontrado)
    {
        cout << setw(10) << left << "\nID";
	    cout << setw(15) << left << "ID PROVEEDOR";
	    cout << setw(10) << left << "CANTIDAD";
	    cout << setw(15) << left << "STOCK M�NIMO";
	    cout << "PRECIO ($)\n"
	         << endl;
	    cout << setw(10) << left << productos[mid].id;
        cout << setw(15) << left << productos[mid].id_proveedor;
        cout << setw(10) << left << productos[mid].stock;
        cout << setw(15) << left << productos[mid].stock_min;
        cout << fixed << setprecision(2) << productos[mid].precio << endl;
        cout << endl;
    }
    else
    {
        cout << "\nNo hemos encontrado un producto con el nombre '"<< busqueda << "'\n\n";
    }

    system("pause");
}

int inicializarArchivos()
{

    ifstream file("Cliente.bin", std::ios::binary | std::ios::ate);
    fstream ClienteOrdenadoAux("ClienteOrdenado.bin", std::ios::in | std::ios::out | std::ios::trunc | std::ios::binary);
    if (!file || !ClienteOrdenadoAux)
    {
        system("cls");
        cout << "No se pudo abrir el archivo: " << strerror(errno);
        EXIT_FAILURE;
    }

    streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    int numEstructuras = size / sizeof(Cliente);

    Cliente *buffer = new Cliente[numEstructuras];
    file.read((char *)buffer, numEstructuras * sizeof(Cliente));
    for (int i = 0; i < numEstructuras; i++)
    {
        for (int j = 0; buffer[i].nombre[j]; j++)
        {
            buffer[i].nombre[j] = toupper(buffer[i].nombre[j]);
        }
    }

    ClienteOrdenadoAux.write((char *)buffer, (numEstructuras) * sizeof(Cliente));
    delete[] buffer;
    ClienteOrdenadoAux.close();

    return numEstructuras;
}

void ordenamientoMezclaDirecta()
{
    int longSec;

    int numEstructuras = inicializarArchivos();

    // Empezamos el ordenamiento en 1
    longSec = 1;

    // Tomamos el tiempo antes de empezar
    struct timeval t, t2;
    int microsegundos;
    gettimeofday(&t, NULL);
    // Revisamos que hayan estructucturas en el binario y con cada iteraci�n vamos haciendo divisiones longSec m�s grandes
    while (longSec < numEstructuras)
    {
        distribuir("ClienteOrdenado.bin", "Izquierda.bin", "Derecha.bin", longSec, numEstructuras);
        mezclar("Izquierda.bin", "Derecha.bin", "ClienteOrdenado.bin", longSec, numEstructuras);
        longSec *= 2;
    }
    // Tomamos el tiempo al terminar y calculamos
    gettimeofday(&t2, NULL);
    microsegundos = ((t2.tv_usec - t.tv_usec) + ((t2.tv_sec - t.tv_sec) * 1000000.0f));
    listarClientes("ClienteOrdenado.bin");
    printf("Ordenamiento por mezcla directa terminado en: %g microsegundos.\n\n", microsegundos);
    system("pause");
}

void distribuir(const char *f, const char *f1, const char *f2, int longSec, int numReg)
{
    int numSec, resto, i;

    // Abrimos bf (copia) en lectura, y los dos auxiliares (bf y pw1) en escritura
    ifstream bf(f, std::ios::binary);
    ofstream pw1(f1, std::ios::binary), pw2(f2, std::ios::binary);

    // longSec es la longitud de una de las mitades, por eso multiplicamos por 2 y calculamos cu�ntas secciones de ese tama�o se pueden formar en el archivo
    numSec = numReg / (2 * longSec);
    // Calculamos si hay alg�n sobrante en estas particiones para manejarlas por separado
    resto = numReg % (2 * longSec);

    // Accedemos a cada divisi�n con los dos archivos auxiliares
    for (i = 1; i <= numSec; i++)
    {
        subSecuencia(bf, pw1, longSec);
        subSecuencia(bf, pw2, longSec);
    }

    // Manejamos el resto, si se puede hacer una seccion completa se guarda en f1 y el restante en f2
    if (resto > longSec)
        resto -= longSec;
    else
    {
        longSec = resto;
        resto = 0;
    }

    subSecuencia(bf, pw1, longSec);
    subSecuencia(bf, pw2, resto);
}

void subSecuencia(std::ifstream &f, std::ofstream &t, int longSec)
{
    // Escribimos las divisiones del archivo principal en el archivo auxiliar recibido correspondiente
    Cliente cliente;
    for (int j = 1; j <= longSec; j++)
    {
        if (f.read((char *)&cliente, sizeof(cliente)))
        {
            t.write((char *)&cliente, sizeof(cliente));
        }
    }
}

void mezclar(const char *f1, const char *f2, const char *f, int lonSec, int numReg)
{
    int numSec, resto, i, j, k;
    Cliente cliente1, cliente2;

    // Nuevamente hacemos particiones para mezclar mitades entre los dos auxiliares
    numSec = numReg / (2 * lonSec);
    resto = numReg % (2 * lonSec);

    // Abrimos los archivos nuevamente (si no se abren y cierran tras cada funci�n la informaci�n no se guardar� correctamente)
    std::ifstream bf1(f1, std::ios::binary), bf2(f2, std::ios::binary);
    std::ofstream pw(f, std::ios::binary);

    // Leemos el primer registro de cada archivo auxiliar y los guardamos en las estructuras de tipo Cliente
    bf1.read((char *)&cliente1, sizeof(cliente1));
    bf2.read((char *)&cliente2, sizeof(cliente2));

    // Se comparan las estructuras de los archivos auxiliares en bloques, y se van escribiendo con el nuevo orden en el archivo copia
    for (int s = 1; s <= numSec + 1; s++)
    {
        int n1, n2;
        n1 = n2 = lonSec;
        if (s == numSec + 1)
        {
            if (resto > lonSec)
                n2 = resto - lonSec;
            else
            {
                n1 = resto;
                n2 = 0;
            }
        }
        i = j = 1;
        while (i <= n1 && j <= n2)
        {
            Cliente cliente;
            if (std::string(cliente1.nombre) < std::string(cliente2.nombre))
            {
                cliente = cliente1;
                if (bf1.read((char *)&cliente1, sizeof(cliente1)))
                {
                    cliente1 = cliente1;
                }
                i++;
            }
            else
            {
                cliente = cliente2;
                if (bf2.read((char *)&cliente2, sizeof(cliente2)))
                {
                    cliente2 = cliente2;
                }
                j++;
            }
            pw.write((char *)&cliente, sizeof(cliente));
        }

        for (k = i; k <= n1; k++)
        {
            pw.write((char *)&cliente1, sizeof(cliente1));
            if (bf1.read((char *)&cliente1, sizeof(cliente1)))
            {
                cliente1 = cliente1;
            }
        }
        for (k = j; k <= n2; k++)
        {
            pw.write((char *)&cliente2, sizeof(cliente2));
            if (bf2.read((char *)&cliente2, sizeof(cliente2)))
            {
                cliente2 = cliente2;
            }
        }
    }
}

void ordenamientoMezclaNatural()
{
    int longSec;
    int numEstructuras = inicializarArchivos();

    // Empezamos el ordenamiento en 1
    longSec = 1;

    // Tomamos el tiempo antes de empezar
    struct timeval t, t2;
    int microsegundos;
    gettimeofday(&t, NULL);

    // Revisamos que hayan estructuras en el binario y con cada iteraci�n vamos haciendo divisiones longSec m�s grandes
    while (longSec < numEstructuras)
    {
        distribuirNatural("ClienteOrdenado.bin", "Izquierda.bin", "Derecha.bin", longSec, numEstructuras);
        mezclar("Izquierda.bin", "Derecha.bin", "ClienteOrdenado.bin", longSec, numEstructuras);
        longSec *= 2;
    }

    // Tomamos el tiempo al terminar y calculamos
    gettimeofday(&t2, NULL);
    microsegundos = ((t2.tv_usec - t.tv_usec) + ((t2.tv_sec - t.tv_sec) * 1000000.0f));
    listarClientes("ClienteOrdenado.bin");
    printf("Ordenamiento por mezcla natural terminado en: %g microsegundos.\n\n", microsegundos);
    system("pause");
}

void distribuirNatural(const char* f, const char* f1, const char* f2, int longSec, int numReg)
{
    int numSec, resto, i;

    // Abrimos bf (copia) en lectura, y los dos auxiliares (bf y pw1) en escritura
    std::ifstream bf(f, std::ios::binary);
    std::ofstream pw1(f1, std::ios::binary), pw2(f2, std::ios::binary);

    // longSec es la longitud de una de las mitades, por eso multiplicamos por 2 y calculamos cu�ntas secciones de ese tama�o se pueden formar en el archivo
    numSec = numReg / (2 * longSec);
    // Calculamos si hay alg�n sobrante en estas particiones para manejarlas por separado
    resto = numReg % (2 * longSec);

    // Accedemos a cada divisi�n con los dos archivos auxiliares
    for (i = 1; i <= numSec; i++)
    {
        subSecuenciaNatural(bf, pw1, longSec);
        subSecuenciaNatural(bf, pw2, longSec);
    }

    // Manejamos el resto, si se puede hacer una seccion completa se guarda en f1 y el restante en f2
    if (resto > longSec)
        resto -= longSec;
    else
    {
        longSec = resto;
        resto = 0;
    }

    subSecuenciaNatural(bf, pw1, longSec);
    subSecuenciaNatural(bf, pw2, resto);
}

void subSecuenciaNatural(std::ifstream &f, std::ofstream &t, int longSec)
{
    // Escribimos las divisiones del archivo principal en el archivo auxiliar recibido correspondiente
    Cliente cliente, clienteAnterior;
    bool primero = true;
    for (int j = 1; j <= longSec; j++)
    {
        if (f.read((char *)&cliente, sizeof(cliente)))
        {
            if (primero)
            {
                t.write((char *)&cliente, sizeof(cliente));
                clienteAnterior = cliente;
                primero = false;
            }
            else
            {
                if (std::string(cliente.nombre) >= std::string(clienteAnterior.nombre))
                {
                    t.write((char *)&cliente, sizeof(cliente));
                    clienteAnterior = cliente;
                }
                else
                {
                    break;
                }
            }
        }
    }
}

