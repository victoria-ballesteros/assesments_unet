# minimax-tic-tac-toe
A game of tictactoe coded in C++ uses minimax algorithm and also alpha-beta pruning

This game is coded in basic C++ without any STL.
This is a single player game. CPU plays it's moves using minimax.
It also has alpha-beta pruning concept to improve the processing efficiency of CPU.
